==== Verse Of The Day ====
Contributors: dalziel
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=paypal%40slaven.net.au&item_name=Verse+Of+The+Day+Wordpress+Plugin&no_note=1&tax=0&bn=PP-DonationsBF&submit.x=51&submit.y=9
Tags: votd, bible, verse, christian
Requires at least: 2.1
Tested up to: 2.2
Stable tag: 3.0

Displays a daily bible verse on your site, using a Verse of the Day RSS feed.  

== Description ==

Displays a daily bible verse on your site, using a Verse of the Day RSS feed.  The feed can come from anywhere, but defaults to the ESV provided by Good News Publishers.

== Installation ==

1. Download the zip file & extract the contents to /wp-content/plugins
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place the tag `wp_votd()` on your template where you want the verse to appear
4. (optional) Modify the version to use and the display template in the options page

== Screenshots ==

1. The Verse of the Day options page
2. An example of the text that is generated on the blog
3. An example of the `wp_votd()` tag in code (highlighted line)